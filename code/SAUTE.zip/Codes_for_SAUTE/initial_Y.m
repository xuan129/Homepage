function [Y] = initial_Y(ori_data, partial_target)



n_of_ins = size(ori_data, 1);
n_of_label = size(partial_target, 1);

Y = zeros(n_of_ins, n_of_label);

for i = 1 : n_of_ins
    count = 0;
    for j = 1 : n_of_label
        if partial_target(j, i) == 1
            count = count + 1;
        end
    end
    if count > 0 
        Y(i, :) = partial_target(:, i)' ./ count;
    end
end

end

