clc;
clear;
close;

load('sample_data.mat');

d = size(data, 2);
ori_data = data;

ratio = 0.05;
k = ceil(ratio * d);
T = 20;
knn = 8;
[lower_data, selected_index] = MI_Based(ori_data, partial_target, k, T, knn);
lower_data
selected_index
