function [H] = getEntropy(ori_data, partial_target, Y)



n_of_ins = size(ori_data, 1);
d = size(ori_data, 2);
n_of_label = size(partial_target, 1);


label_ins_mem = zeros(n_of_ins, d, n_of_label);

label_ins_num = zeros(1, n_of_label);


n_candidate = zeros(1, n_of_ins);
for i = 1 : n_of_ins
    for j = 1 : n_of_label
        if partial_target(j, i) == 1
            n_candidate(1, i) = n_candidate(1, i) + 1;
        end
    end
end


for i = 1 : n_of_ins
    threshold = 1 / n_candidate(1, i);
    
    for j = 1 : n_of_label
        if Y(i, j) >= threshold
            label_ins_num(1, j) = label_ins_num(1, j) + 1;
            index = label_ins_num(1, j);
            label_ins_mem(index, :, j) = ori_data(i, :);
        end
        
    
    end
end


label_mean = zeros(n_of_label, d);
label_std = zeros(n_of_label, d);

for j = 1 : n_of_label
    if label_ins_num(j) ~= 0
        num = label_ins_num(j);
        page = label_ins_mem(1:num, :, j);
        
        label_mean(j, :) = mean(page);
        label_std(j, :) = std(page);
    end
end


p_y = sum(Y);
p_y = p_y ./ sum(p_y);




H = zeros(1, d);
for i = 1 : d
    
    pdf_xgivenc = zeros(n_of_ins, n_of_label);
    for j = 1 : n_of_ins
        for k = 1 : n_of_label
            if label_std(k, i) ~= 0     
                pdf_xgivenc(j, k) = normpdf(ori_data(j, i), label_mean(k, i), label_std(k, i));
            end
        end
    end
    
    pdf_cgivenx = zeros(n_of_ins, n_of_label);
    for j = 1 : n_of_ins
        for k = 1 : n_of_label
            if label_std(k, i) ~= 0
                nouse = p_y .* pdf_xgivenc(j, :);
                temp = sum(p_y .* pdf_xgivenc(j, :));
                pdf_cgivenx(j, k) = p_y(k) * pdf_xgivenc(j, k) / temp;
            end
        end
    end
   
    [row, col, v] = find(pdf_cgivenx);
    temp = v .* (log(v) ./ log(2));
    H(i) = - sum(temp);
    
end

H = H ./ n_of_ins;      
    
end

