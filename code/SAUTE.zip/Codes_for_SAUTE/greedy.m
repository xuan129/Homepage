function [S] = greedy(ori_data, discrete_data, partial_target, k, Y)



n_of_ins = size(discrete_data, 1);
n_of_label = size(partial_target, 1);
n_of_feature = size(discrete_data, 2);


n_avelabel = sum(sum(partial_target)) / n_of_ins;
n_avelabel = ceil(n_avelabel);


S = zeros(1, k);

choosed = zeros(1, n_of_feature);


pY = sum(Y);
pY = pY ./ sum(pY);


n_candidate = zeros(1, n_of_ins);
for i = 1 : n_of_ins
    for j = 1 : n_of_label
        if partial_target(j, i) == 1
            n_candidate(i) = n_candidate(i) + 1;
        end
    end
end
n_candidate = n_candidate';


H_ygivenx = getEntropy(ori_data, partial_target, Y);    


for i = 1 : k
    MIvalue = zeros(1, n_of_feature);
    MIvalue(1, :) = -999999;    
    for j = 1 : n_of_feature
        if choosed(j) == 0
            considered_feature = discrete_data(:, j);

            
            MIvalue(j) = - H_ygivenx(j);

            if i ~= 1
                sumMI = 0;
                curnum = i - 1;
                for q = 1 : curnum
                    curfea = discrete_data(:, S(q));
                    curmi = mutualinfo(curfea, considered_feature);

                    sumMI = sumMI + curmi;
                end
                MIvalue(j) = MIvalue(j) - 1 / curnum * sumMI;
            end
        end
    end
    
    [maxvalue, index] = max(MIvalue);
    index = index(1);
    S(i) = index;
    choosed(index) = 1;
    
end



end

