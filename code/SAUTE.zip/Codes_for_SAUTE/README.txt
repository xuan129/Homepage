***************************************************************************
MATLAB toolbox for the partial label feature selection algorithm SAUTE

Copyright: 
		Wei-Xuan Bao (baowx@seu.edu.cn),
		Jun-Yi Hang (hangjy@seu.edu.cn)
 	    Min-Ling Zhang (zhangml@seu.edu.cn)
 		School of Computer Science and Engineering, Southeast University, Nanjing 210096, China

This code package can be used freely for academic, non-profit purposes. For other usage, 
please contact us for further information (Prof. Min-Ling Zhang: zhangml@seu.edu.cn ).
***************************************************************************

0. Contents
===========================================================================
0. Contents
1. Introduction
2. Requirements
3. Installation
4. How to start?

1.Introduction
===========================================================================
This package implements a novel partial label feature selection algorithm named SAUTE. 

2. Requirements
===========================================================================
- Matlab, version 2015b and higher.

3. Installation
===========================================================================
- Create a directory of your choice.
- Set the path in your Matlab to add the directory you just created.

4. How to start?
===========================================================================
To help you start working with CENDA, we provide a demo(See demo.m) in this package. 
You can follow the procedure as described in the demo.

It is worth mentioning that an additional matlab toolbox (mi.0.912.zip) for mutual information computation is needed for SAUTE. 
You can find more information about this toolbox at:
https://ww2.mathworks.cn/matlabcentral/fileexchange/14888-mutual-information-computation.

Please read and play with the demo to get started. Have fun!
