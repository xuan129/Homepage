function [discrete_data] = discrete(ori_data)

mean_data = mean(ori_data);
std_data = std(ori_data);

nrow = size(ori_data, 1);
ncol = size(ori_data, 2);

discrete_data = zeros(nrow, ncol);

for i = 1 : nrow
    for j = 1 : ncol
        if ori_data(i, j) <= mean_data(j) - 2 * std_data(j)
            discrete_data(i, j) = -2;
        elseif ori_data(i, j) <= mean_data(j) - std_data(j)
            discrete_data(i, j) = -1;
        elseif ori_data(i, j) <= mean_data(j) + std_data(j)
            discrete_data(i, j) = 0;
        elseif ori_data(i, j) <= mean_data(j) + 2 * std_data(j)
            discrete_data(i, j) = 1;
        elseif ori_data(i, j) > mean_data(j) + 2 * std_data(j)
            discrete_data(i, j) = 2;
        end
    end
end






end

