function [lower_data, selected_index] = MI_Based(ori_data, partial_target, k, T, knn)


Y = initial_Y(ori_data, partial_target);

discrete_data = discrete(ori_data);

for iteration = 1 : T   
    
    index = greedy(ori_data, discrete_data, partial_target, k, Y);
    selected_index = index;
    
    lower_data = ori_data(:, index);
    [Y] = Y_update(lower_data', partial_target, Y, knn);
    
end

end
