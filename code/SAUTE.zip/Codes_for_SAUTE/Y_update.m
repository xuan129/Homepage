function [Y_new] = Y_update(lower_train_data, partial_target, Y_ori, k)



lower_train_data = lower_train_data';

D = size(lower_train_data, 2);              
M = size(lower_train_data, 1);              
Q = size(partial_target, 1);    

LabelSet = zeros(Q, M + 6);     
InsSet = zeros(M, Q + 6);       

train_p_target = partial_target';
for i = 1:M
    for j = 1:Q
        if train_p_target(i, j) == 1
            LabelSet(j, 1) = LabelSet(j, 1) + 1;
            t = LabelSet(j, 1);
            LabelSet(j, t + 1) = i;
            
            InsSet(i, 1) = InsSet(i, 1) + 1;
            t = InsSet(i, 1);
            InsSet(i, t + 1) = j;
        end
    end
end




lower_train_data = lower_train_data';

M = size(lower_train_data, 2);
Q = size(Y_ori, 2);

data = lower_train_data';       


Mdl = KDTreeSearcher(data); 
[Idx] = knnsearch(Mdl, data, 'k', k + 1);
Idx = Idx(:, 2:end);


Z = zeros(M, Q);
V = zeros(M, Q);
for i = 1:M
    neighbours = Idx(i, :);
    
    for nei = 1:k
        ind = neighbours(nei);
        
        nLabels = InsSet(ind, 1);
        Labels = InsSet(ind, 2:(nLabels + 1));
        
        for it = 1:nLabels
            j = Labels(it);
            Z(i, j) = Z(i, j) + Y_ori(ind, j) * (k - nei + 1);
            V(i, j) = V(i, j) + 1;
        end
        
    end
end


Z_New = Y_ori;
alpha = 0.6;    
for i = 1:M
    nLabels = InsSet(i, 1);
    Labels = InsSet(i, 2:(nLabels + 1));
    
    for it = 1:nLabels
        j = Labels(it);
        Z_New(i, j) = (1 - alpha) * Z_New(i, j) + alpha * Z(i, j);
    end
    
    
    
    if sum(Z_New(i, :)) ~= 0
        Z_New(i, :) = Z_New(i, :) ./ sum(Z_New(i, :));
    else
        Z_New(i, :) = Y_ori(i, :);
    end
end

Y_new = Z_New;



end

